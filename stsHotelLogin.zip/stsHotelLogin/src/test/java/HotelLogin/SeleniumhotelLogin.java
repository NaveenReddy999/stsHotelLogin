package HotelLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumhotelLogin {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module%203/hotelBooking/login.html/");
       String stsheading=  driver.findElement(By.xpath(".//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
	if(stsheading.contentEquals("Hotel Booking Application")) {
		System.out.println("Heading Matched");
	}
	else
	{
		System.out.println("Heading Not Matched");
	}
	Thread.sleep(1000);
	//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	driver.findElement(By.name("userName")).sendKeys("capgemini");
	Thread.sleep(1000);
	
	driver.findElement(By.name("userPwd")).sendKeys("capg1234");
	//driver.findElement(By.name("userPwd")).sendKeys("capg12");
	
	Thread.sleep(1000);
	driver.findElement(By.className("btn")).click();
	
	String alertMessage= driver.switchTo().alert().getText();
	Thread.sleep(5000);
	System.out.println(alertMessage);
	
	driver.switchTo().alert().accept();
	//driver.switchTo().alert();
	
	driver.navigate().to("file:///D:/Module%203/hotelBooking/hotelbooking.html");
	
	System.out.println(driver.getCurrentUrl());
	//driver.close();
	//driver.quit();
	}

}
