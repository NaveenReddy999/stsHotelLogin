package HotelBooking;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

@Given("^User is on booking page$")
public void user_is_on_booking_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^check the title of the page$")
public void check_the_title_of_the_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Given("^user is on hotel Booking page$")
public void user_is_on_hotel_Booking_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters all the required fields$")
public void user_enters_all_the_required_fields() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^navigate to welcome page$")
public void navigate_to_welcome_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Given("^User is on hotel booking page$")
public void user_is_on_hotel_booking_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user leaves first name blank$")
public void user_leaves_first_name_blank() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^clicks the button$")
public void clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^display alert message$")
public void display_alert_message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user leaves the lastt name blank and clicks the button$")
public void user_leaves_the_lastt_name_blank_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters all the data$")
public void user_enters_all_the_data() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters incorrect email format and clicks the button$")
public void user_enters_incorrect_email_format_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user leaves the mobile number blank and clicks the button$")
public void user_leaves_the_mobile_number_blank_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters incorrect mobileNo format and clicks the button$")
public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    // For automatic transformation, change DataTable to one of
    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
    // E,K,V must be a scalar (String, Integer, Date, enum etc)
    throw new PendingException();
}

@Then("^displat alert message$")
public void displat_alert_message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user doesnot selects city and clicks the button$")
public void user_doesnot_selects_city_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user doesnot selects state and clicks the button$")
public void user_doesnot_selects_state_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters (\\d+)$")
public void user_enters(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Given("^User is on hotel Booking page$")
public void user_is_on_hotel_Booking_page1() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user leaves CardHolderName blank and clicks the button$")
public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user leaves DebitCard no\\. blank and clicks the button$")
public void user_leaves_DebitCard_no_blank_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user leaves CVV blank and clicks the button$")
public void user_leaves_CVV_blank_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user leaves Expiration month blank and clicks the button$")
public void user_leaves_Expiration_month_blank_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
}

@When("^user leaves Expiration year blank and clicks the button$")
public void user_leaves_Expiration_year_blank_and_clicks_the_button() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
}


}
