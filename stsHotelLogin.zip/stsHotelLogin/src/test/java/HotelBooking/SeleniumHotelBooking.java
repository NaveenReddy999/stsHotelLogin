package HotelBooking;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumHotelBooking {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module%203/hotelBooking/hotelbooking.html/");
       String ststitle= driver.getTitle();
	if(ststitle.contentEquals("Hotel Booking")) {
		System.out.println("Title Matched");
	}
	else
	{
		System.out.println("Title Not Matched");
	}
	driver.findElement(By.name("txtFN")).sendKeys("");
	Thread.sleep(2000);
	/*WebElement btn=driver.findElement(By.className("btn"));
	btn.click();*/
	driver.findElement(By.id("btnPayment")).click();
	Thread.sleep(1000);
	String alertMessage=driver.switchTo().alert().getText();
	Thread.sleep(1000);
	System.out.println(alertMessage);
	
	driver.switchTo().alert().accept();
	}
            
}
